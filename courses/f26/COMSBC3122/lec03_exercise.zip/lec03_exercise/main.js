/* ===========================================================================
   COMS BC3122 (Sep 16): Introduction to web programming, JavaScript, and D3
   =========================================================================== */

// Everything goes inside an async function so we can `await` the data load. 
// A plain <script> cannot `await` at the top level, so we define
// main() and call it on the last line of the file.
async function main() {

  // -- 1. Hello, D3: select, append, text ------------------------------------
  // your code goes here

  // -- 2. One circle per sandwich: data join -----------------------------
  // Uncomment this when you are ready
  // const sandwiches = [
  //   { name: "Thesis",       price: 7.95,  size: "large" },
  //   { name: "Dissertation", price: 8.95,  size: "large" },
  //   { name: "Highlander",   price: 6.50,  size: "small" },
  //   { name: "Just Tuna",    price: 6.50,  size: "small" },
  //   { name: "So-La",        price: 7.95,  size: "large" },
  //   { name: "Special",      price: 12.50, size: "small" }
  // ];
  // your code goes here
}

main().catch(err => {
  console.error(err);
  document.querySelector("#chart").innerHTML =
    "<p style='background:#fdf2f0;border:1px solid #e6bfb8;padding:12px'>" +
    "<b>Something went wrong.</b> Press F12 and read the Console. " +
    "If it mentions CORS, fetch, or <code>file://</code>, you opened this " +
    "file by double-clicking it — start a local server instead.</p>";
});
