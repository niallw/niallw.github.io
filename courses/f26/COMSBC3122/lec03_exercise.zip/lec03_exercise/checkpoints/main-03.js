/* CHECKPOINT 07 — the finished version: colour by size, a label on every bar,
   dollar ticks. This is the tab you show at the start and the file you fall back
   to if something breaks live. Everything past checkpoint 06 is a "now you" task. */

async function main() {

  // your code goes here
  // -- 1. HELLO, D3 — select, append, text ------------------------------------
  d3.select("#circles").append("p").text("Hello, D3!");

  // -- 2. ONE CIRCLE PER SANDWICH — the data join -----------------------------
  const sandwiches = [
    { name: "Thesis",       price: 7.95,  size: "large" },
    { name: "Dissertation", price: 8.95,  size: "large" },
    { name: "Highlander",   price: 6.50,  size: "small" },
    { name: "Just Tuna",    price: 6.50,  size: "small" },
    { name: "So-La",        price: 7.95,  size: "large" },
    { name: "Special",      price: 12.50, size: "small" }
  ];

  const svg = d3.select("#circles").append("svg")
      .attr("width", 500)
      .attr("height", 100);

  svg.selectAll("circle")
    .data(sandwiches)
    .join("circle")
      .attr("cx", (d, i) => 50 + i * 80)
      .attr("cy", 50)
      .attr("r", d => d.size === "large" ? 20 : 10)
      .attr("fill", d => d.price < 7 ? "#3f7d4e" : "#c1533c")
      .attr("stroke-width", d => d.size === "large" ? 5 : 1)
      .attr("stroke", "#333");

  svg.selectAll("text")
    .data(sandwiches)
    .join("text")
      .attr("x", (d, i) => 50 + i * 80)
      .attr("y", 90)
      .attr('font-size', 10)
      .text(d => d.name);

  // -- 3. Load the csv file
  const data = await d3.csv("data/sandwiches.csv", d => ({
    name:  d.name,
    price: +d.price,
    size:  d.size
  }));
  console.log("rows:", data.length);
  console.table(data);

}

main().catch(err => {
  console.error(err);
  document.querySelector("#chart").innerHTML =
    "<p style='background:#fdf2f0;border:1px solid #e6bfb8;padding:12px'>" +
    "<b>Something went wrong.</b> Press F12 and read the Console. " +
    "If it mentions CORS, fetch, or <code>file://</code>, you opened this " +
    "file by double-clicking it — start a local server instead.</p>";
});
