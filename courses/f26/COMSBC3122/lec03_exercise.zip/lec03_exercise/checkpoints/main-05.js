/* CHECKPOINT 07 — the finished version: colour by size, a label on every bar,
   dollar ticks. This is the tab you show at the start and the file you fall back
   to if something breaks live. Everything past checkpoint 06 is a "now you" task. */

async function main() {

  // your code goes here
  // -- 1. HELLO, D3 — select, append, text ------------------------------------
  d3.select("#circles").append("p").text("Hello, D3!");

  // -- 2. ONE CIRCLE PER SANDWICH — the data join -----------------------------
  const sandwiches = [
    { name: "Thesis",       price: 7.95,  size: "large" },
    { name: "Dissertation", price: 8.95,  size: "large" },
    { name: "Highlander",   price: 6.50,  size: "small" },
    { name: "Just Tuna",    price: 6.50,  size: "small" },
    { name: "So-La",        price: 7.95,  size: "large" },
    { name: "Special",      price: 12.50, size: "small" }
  ];

  const svg = d3.select("#circles").append("svg")
      .attr("width", 500)
      .attr("height", 100);

  svg.selectAll("circle")
    .data(sandwiches)
    .join("circle")
      .attr("cx", (d, i) => 50 + i * 80)
      .attr("cy", 50)
      .attr("r", d => d.size === "large" ? 20 : 10)
      .attr("fill", d => d.price < 7 ? "#3f7d4e" : "#c1533c")
      .attr("stroke-width", d => d.size === "large" ? 5 : 1)
      .attr("stroke", "#333");

  svg.selectAll("text")
    .data(sandwiches)
    .join("text")
      .attr("x", (d, i) => 50 + i * 80)
      .attr("y", 90)
      .attr('font-size', 10)
      .text(d => d.name);

  // -- 3. Load the csv file
  const data = await d3.csv("data/sandwiches.csv", d => ({
    name:  d.name,
    price: +d.price,
    size:  d.size
  }));
  console.log("rows:", data.length);
  console.table(data);

  // -- 4. Frame and Scales
  // Margin convention: an <svg> of the full size, containing a <g> shifted
  // inward by the margins. Everything we draw goes inside `chart`, whose (0,0)
  // is the top-left of the plot area.
  const margin = { top: 20, right: 20, bottom: 40, left: 50 };
  const width  = 520 - margin.left - margin.right;    // 450
  const height = 320 - margin.top  - margin.bottom;   // 260

  const chart = d3.select("#chart").append("svg")
      .attr("viewBox", [0, 0, 520, 320])              // not width/height
    .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

  // A scale is a fuction: it maps data values in a domain to a range of pixel values
  const x = d3.scaleBand()                            // categories -> bands/groups
      .domain(data.map(d => d.name))
      .range([0, width])
      .padding(0.2);

  const y = d3.scaleLinear()                          // numbers -> pixels
      .domain([0, d3.max(data, d => d.price)])
      .range([height, 0]);                            // inverted: SVG y grows downwards


  // -- 5. Axes
  // d3.axisBottom(x) is a function that draws an axis into whatever you .call()
  // it on. Make an empty <g>, move it to the bottom, and let the axis fill it in.
  chart.append("g").attr("class", "axis")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x));

  chart.append("g").attr("class", "axis")
      .call(d3.axisLeft(y).ticks(5, "$.2f"));       // 5 ticks, formatted as dollars



}

main().catch(err => {
  console.error(err);
  document.querySelector("#chart").innerHTML =
    "<p style='background:#fdf2f0;border:1px solid #e6bfb8;padding:12px'>" +
    "<b>Something went wrong.</b> Press F12 and read the Console. " +
    "If it mentions CORS, fetch, or <code>file://</code>, you opened this " +
    "file by double-clicking it — start a local server instead.</p>";
});
