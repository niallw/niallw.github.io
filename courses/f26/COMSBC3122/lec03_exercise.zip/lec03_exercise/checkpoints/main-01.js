/* CHECKPOINT 07 — the finished version: colour by size, a label on every bar,
   dollar ticks. This is the tab you show at the start and the file you fall back
   to if something breaks live. Everything past checkpoint 06 is a "now you" task. */

async function main() {

  // your code goes here
  // -- 1. HELLO, D3 — select, append, text ------------------------------------
  d3.select("#circles").append("p").text("Hello, D3!");



}

main().catch(err => {
  console.error(err);
  document.querySelector("#chart").innerHTML =
    "<p style='background:#fdf2f0;border:1px solid #e6bfb8;padding:12px'>" +
    "<b>Something went wrong.</b> Press F12 and read the Console. " +
    "If it mentions CORS, fetch, or <code>file://</code>, you opened this " +
    "file by double-clicking it — start a local server instead.</p>";
});
